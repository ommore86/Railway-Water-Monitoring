const express = require("express");
const cors = require("cors");
require("dotenv").config();

const dashboardRoutes = require("./routes/dashboardRoutes");
const authRoutes = require("./routes/authRoutes");
const sensorRoutes = require("./routes/sensor.routes");

const app = express();

app.use(cors({ origin: "*" }));
app.use(express.json());

// Routes
app.use("/api", dashboardRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/sensor", sensorRoutes);

// Test route
app.get("/", (req, res) => {
    res.send("🚆 Railway Water Monitoring Backend Running");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log("Server running on port " + PORT));